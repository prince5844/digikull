Copyright (C) 2020 by Aditya R, Institute of Technology, Nirma University.

# Playing-with-data-using-python
A project using SQL, SQL connectivity, Numpy, Matplotlib. 

Output:

![demo1](https://user-images.githubusercontent.com/68019168/124969548-775e5180-e044-11eb-8dfb-f8370076ffab.PNG)

![demo2](https://user-images.githubusercontent.com/68019168/124969547-76c5bb00-e044-11eb-9817-29bfa1b83f41.PNG)

![demo3](https://user-images.githubusercontent.com/68019168/124969505-6a416280-e044-11eb-9f1b-79eee68bc776.PNG)

