#Write a program that uses a print statement to say 'hello world' as shown in 'Desired Output'.
print("hello world")