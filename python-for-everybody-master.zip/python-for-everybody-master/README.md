# python-for-everybody
Assignment solutions for python-for-everybody Chapter 1 to 15 (refer to https://www.py4e.com/ for details)
Many thanks to Dr Charles Severance for offering the open and free version of the course
